#include "knight.h"
#include"weapon.h"
#include"Random.h"
#include<iostream>
#include<string>
using namespace std;
int main()
{
  int stamina, stam_req, hit_chance, i=1;
  string name, weapon_name;
  knight kn1, kn2;
  cout << "what are the nights names?" << endl;
  cout << "Knight 1: " << endl;
  getline (cin, name);
  cout << "stamina levels " << endl;
  cin >> stamina;
  cin.ignore();
  cout<<"Their weapon:";
  getline (cin,weapon_name);
  cout<<"Stamina required:";
  cin>>stam_req;
  cout<<"Weapon's hit chance(1 in 6):";
  cin>>hit_chance; 
  cin.ignore(1000, '\n');
  kn1.set(name, stamina, weapon_name, stam_req, hit_chance);

  cout<<"\nCombatiant #2"<<endl<<"Knight's Name: ";
  getline (cin,name);
  cout<<"Stamina:";
  cin>>stamina;
  cin.ignore(1000, '\n');
  cout<<"Their weapon:";
  getline (cin,weapon_name);
  cout<<"Stamina required:";
  cin>>stam_req;
  cout<<"Weapon's hit chance(1-6):";
  cin>>hit_chance;
  kn2.set(name, stamina, weapon_name, stam_req, hit_chance);
  do
  {
    cout<<"\n\n\nROUND "<<i<<endl;

    if(kn1.charge())
      kn2.unhorse();
    if(kn2.charge())
      kn1.unhorse();

    kn1.display();
    cout<<endl<<endl;
    kn2.display();

    i++;
  }while(!kn1.exhausted() && kn1.onhorse() && !kn2.exhausted() && kn2.onhorse());
return 0;
}
