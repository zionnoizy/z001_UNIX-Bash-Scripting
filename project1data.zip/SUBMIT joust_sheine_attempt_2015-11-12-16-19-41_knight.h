#ifndef KNIGHT_H
#define KNIGHT_H
#include <string>
class knight
{
  private:
    int stamina;
    string name;
    bool on_horse;
    Weapon weapon_weilded;

  public:
    bool charge();
    void unhorse():
    bool exhausted();
    bool onhorse();
    void display();
    void set(string n, int s, string t, int sr, int hc)
    {
      name=n;
      stamina=s;
      weapon_weilded.set(t,sr,hc)
      on_horse=true;
    }
};
#endif
