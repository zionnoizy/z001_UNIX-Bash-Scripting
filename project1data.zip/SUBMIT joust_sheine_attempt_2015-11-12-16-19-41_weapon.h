#ifndef WEAPON_H
#define WEAPON_H
#include <string>
class Weapon
{
  private:
    int samina_req , hit_chance;
    string name;
  public:
    void set(string, int, int);
    void display();
    int get_stamina();
    bool hit();
};

#endif
