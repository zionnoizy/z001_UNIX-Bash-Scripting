#include"knight.h"
#include <iostream>
#include<string>
bool knight::charge()
{
  if (stamina > 0)
  {
    stamina = stamina - weapon_weilded.get_stamina();
    if (weapon_weilded.hit())
      return true;
    else
      return false;
  }else
    return false;
}
void knight::unhorse()
{
  on_horse = false;
}
bool knight::exhausted()
{
  if (stamina>0)
    return false;
  else
    return true;
}
bool knight::onhorse()
{
  if(on_horse
      return true;
      else
      return false;
      }
      void knight::display()
      {
      cout<<name <<" is ";
      if (on_horse)
      cout << "on horse ";
      else
      cout << "off horse, ";
      if(exhausted())
      cout << "and is exhausted \n";
      else cout << "with " << stamina << " stamina.\n";
      cout << name << " is weilding a ";
      weapon_weilded.display();
      }
