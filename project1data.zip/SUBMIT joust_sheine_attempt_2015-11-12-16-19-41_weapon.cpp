#include <iostream>
#include<string>
#include "weapon.h"
void Weapon::set(string n, int s, int h)
{
  name=n;
  samina_req=s;
  hit_chance=h;
}
void Weapon::display()
{
  cout << name << " requires " << stamina_req << "stamina and has a hit chance of " << hit_chance;
}
int Weapon::get_stamina()
{
  return stamina_req;
}
bool Weapon::hit()
{
  Random chance(1, hit_chance);
  if (chance.get() == hit_chance)
    return true;
  else
    return false;
}

